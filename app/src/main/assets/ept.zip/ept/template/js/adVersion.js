adVersion = "Vad20170101";
eptVersion = "V2017012101";

/*页脚/取消操作js*/
function zhuye(){
	window.location.href="main.html";
}
function qx(r){
	document.getElementById(r).reset(); 
	//$(this).blur();
}
//window.onload=function()
//{
//var url = window.location.href;
//if(url.indexOf("#")!=-1){
//	window.location.href="main.html";
//}

//}
//function houtui(){
//	window.history.back("-1");
//}
eptVersion = "V2017012101";
adVersion = "Vad20170101";

/*固定数据js*/
function bb(){
	var bbdata="";
	$.ajax({
		url:"qddata/bb.txt",
		async:false,
		success:function(text){
			bbdata = eval("("+text+")");
		}
	});
	return bbdata;
}

function zzdw(){
	var zzdwdata= "";
	$.ajax({
		url:"qddata/zzdw.txt",
		async:false,
		success:function(text){
			zzdwdata = eval("("+text+")");
		}
	});
	return zzdwdata;
}
/**常用比率*/
function cybl(){
	var cybldata= "";
	$.ajax({
		url:"qddata/cybl.txt",
		async:false,
		success:function(text){
			cybldata = eval("("+text+")");
		}
	});
	return cybldata;
}
/**访问地址*/
function fwdz(){
	return "http://192.168.0.110:8080/tongjihz/";
}